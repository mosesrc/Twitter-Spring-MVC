package com.tts.TechTalentTwitter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechTalentTwitterApplicationTests {

	@Test
	void contextLoads() {
	}

}
